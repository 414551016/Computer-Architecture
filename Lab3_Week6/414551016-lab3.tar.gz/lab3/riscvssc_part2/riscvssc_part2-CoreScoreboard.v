// Youngest-producer scoreboard for both five-stage execution pipelines.
// Stage 0..4 correspond to X0, X1, X2, X3, W. Older matches are
// overwritten by younger ones, including a younger not-ready producer.
`ifndef RISCV_CORE_SCOREBOARD_V
`define RISCV_CORE_SCOREBOARD_V
module riscv_CoreScoreboard (
  input clk, reset,
  input [4:0] src00, src01, src10, src11,
  input src00_en, src01_en, src10_en, src11_en,
  output stall_0_hazard, stall_1_hazard,
  output [3:0] src00_byp_mux_sel, src01_byp_mux_sel,
               src10_byp_mux_sel, src11_byp_mux_sel,
  input [4:0] dstA, dstB,
  input dstA_en, dstB_en, is_muldiv_A, is_load_A, is_fastmul_A,
  input stall_X0hl, stall_X1hl
);
  reg [4:0] va, vb;
  reg [4:0] da[0:4], db[0:4];
  reg [4:0] md, ld, fm;
  integer s;
  always @(posedge clk) begin
    if (reset) begin
      va<=0; vb<=0; md<=0; ld<=0; fm<=0;
      for(s=0;s<5;s=s+1) begin da[s]<=0; db[s]<=0; end
    end else begin
      if (!stall_X0hl) begin
        va[0]<=dstA_en && dstA!=0; vb[0]<=dstB_en && dstB!=0;
        da[0]<=dstA; db[0]<=dstB; md[0]<=is_muldiv_A; ld[0]<=is_load_A; fm[0]<=is_fastmul_A;
      end
      if (!stall_X1hl) begin
        va[1]<=va[0] && !stall_X0hl; vb[1]<=vb[0] && !stall_X0hl;
        da[1]<=da[0]; db[1]<=db[0]; md[1]<=md[0]; ld[1]<=ld[0]; fm[1]<=fm[0];
      end
      va[2]<=va[1] && !stall_X1hl; vb[2]<=vb[1] && !stall_X1hl;
      da[2]<=da[1]; db[2]<=db[1]; md[2]<=md[1]; ld[2]<=ld[1]; fm[2]<=fm[1];
      for(s=3;s<5;s=s+1) begin
        va[s]<=va[s-1]; vb[s]<=vb[s-1]; da[s]<=da[s-1]; db[s]<=db[s-1];
        md[s]<=md[s-1]; ld[s]<=ld[s-1]; fm[s]<=fm[s-1];
      end
    end
  end
  wire [4:0] src[0:3];
  wire [3:0] en;
  wire [3:0] sel[0:3];
  wire [3:0] wait_src;
  assign src[0]=src00; assign src[1]=src01; assign src[2]=src10; assign src[3]=src11;
  assign en={src11_en,src10_en,src01_en,src00_en};
  genvar q;
  generate for(q=0;q<4;q=q+1) begin: query
    reg [3:0] selection;
    reg waiting;
    integer k;
    always @(*) begin
      selection=0; waiting=0;
      if(en[q] && src[q]!=0) begin
        for(k=4;k>=0;k=k-1) begin
          if(va[k] && da[k]==src[q]) begin
            selection=k+1;
            waiting=(md[k] && (fm[k] ? k<1 : k<3)) || (ld[k] && k==0);
          end
          if(vb[k] && db[k]==src[q]) begin
            selection=k+6; waiting=0;
          end
        end
      end
    end
    assign sel[q]=selection; assign wait_src[q]=waiting;
  end endgenerate
  assign src00_byp_mux_sel=sel[0]; assign src01_byp_mux_sel=sel[1];
  assign src10_byp_mux_sel=sel[2]; assign src11_byp_mux_sel=sel[3];
  assign stall_0_hazard=wait_src[0] || wait_src[1];
  assign stall_1_hazard=wait_src[2] || wait_src[3];
endmodule
`endif
